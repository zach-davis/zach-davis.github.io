//////////////////////////////////////////
//THIS CONTAINS THE JAVASCRIPT FOR A TRIAL
//////////////////////////////////////////


var count = 0; //For keeping track of how long the process has run for
var timeout = 200;//How many steps to run for (10 steps per second)
var delay = 100; //How many ms per step
var mu = 20;
var lambda = .1;
var sigma = 5;
var x0 = 0;
var intervention = 'none';
var stage_off = false;
var trial_data = {};
var judge_vals = ["inverted","none","regular"];
var judged = [0,0,0,0]; //which response sliders have been judged
var the_process;
var score = 0; //Participant score
var int_state = 0;
var target_region = [10,70]; //Upper percentage of target region

var networks = [
					  //[xy,xz,yx,yz,zx,zy]
    {"id":[0],  "betas":[ 1, 1, 0, 0, 0, 0]}, //Common cause ++
    {"id":[1],  "betas":[ 1,-1, 0, 0, 0, 0]}, //Common cause +-
    {"id":[2],  "betas":[-1, 0, 0, 1, 0, 0]}, //Chain +- (same control beh)
    {"id":[3],  "betas":[ 0, 1, 0, 0, 0,-1]}, //Chain -- (diff control beh)
    {"id":[4],  "betas":[ 1, 1, 0,-1, 0, 0]}, //Simpsons paradox
    {"id":[5],  "betas":[-1,-1, 0, 0, 0, 1]}, //Two path
    {"id":[6],  "betas":[ 1, 0, 0, 1, 0, 1]}, //Chain loop
    {"id":[7],  "betas":[ 0,-1, 0, 1, 0,-1]}, //Chain loop
    {"id":[8],  "betas":[ 1, 1, 0,-1, 0, 1]}, //Complex simpson's
    {"id":[9],  "betas":[-1,-1, 0,-1, 0,-1]}, //Complex
]

document.addEventListener("keydown", function(event) {
   //console.log(event.key);
   if (event.key=='o')
   {
   	   int_state = 1;
   	} else if (event.key=='k')
   	{
		int_state = 2;
   	} else if (event.key=='m')
   	{
   		int_state = 3;
   	} else {
   		int_state = 0;
   	}
   	$('#custom-handlex').css({color:'blue'})
});

document.addEventListener("keyup", function(event) {
   int_state = 0;
   $('#custom-handlex').css({color:'black'})
});

// Update the count down every 1 second
var countdown_timer = setInterval(function() {

    // Get todays date and time
    var now = Date.parse(new Date());
    // Get time of deadline
    var trial_duration = timeout/10;//Timeout in seconds
    var deadline = new Date(now + trial_duration*60*1000);
    
    // Find the distance between now an the count down date
    var distance = deadline - now;
    
    // Time calculations for days, hours, minutes and seconds
    // var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    // var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    // var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
}, 1000);

//For updating the text box next to each slider to the sliders' value
function updateOutput(el, val) {
  el.textContent = val;
}

function Run(betas, cur_phase)
{
	// Selects a random variable to be the target variable (for condition 0)
	// or the first target variable (for condition 1)
	//rand_variable = Math.floor(Math.random() * 2);  //returns a random number, 0 or 1

	$( function() {
	var handle = $( "#custom-handlex" );
	$( "#slidex" ).slider({
	  orientation: "vertical",
	  animate: true,
	  range: "none",
	  min: -100000,
	  max: 100000,
	  value: 0,
	  disabled: false,
	  create: function() {
	    handle.text( Math.round($( this ).slider( "value" )/1000) );
	  },
	  slide: function( event, ui ) {
	  	return false;
	  	//handle.text(Math.round(ui.value/1000));
	  }
	});
	//Functionality to stop the controlled sliders jittering
	$("#slidex").mousedown(function() {
		return false;
	});
	} );

	$( function() {
	var handle = $( "#custom-handley" );
	$( "#slidey" ).slider({
	  orientation: "vertical",
	  animate: true,
	  range: "none",
	  min: -100000,
	  max: 100000,
	  value: 0,
	  alpha: 0.5,
	  disabled: false,
	  create: function() {
	    handle.text( $( this ).slider( "value" ) );
	  },
	  slide: function( event, ui ) {
	  	return false;
	  	//handle.text(Math.round(ui.value/1000));
	  }
	});
	//Functionality to stop the controlled sliders jittering
	$("#slidey").mousedown(function() {
		return false;
	});
	} );

	$( function() {
	var handle = $( "#custom-handlez" );
	$( "#slidez" ).slider({
	  orientation: "vertical",
	  animate: true,
	  range: "none",
	  min: -100000,
	  max: 100000,
	  value: 0,
	  alpha: 0.5,
	  disabled: false,
	  create: function() {
	    handle.text( $( this ).slider( "value" ) );
	  },
	  slide: function( event, ui ) {
	  	return false;
	  	//handle.text(Math.round(ui.value/1000));
	  }
	});
	//Functionality to stop the controlled sliders jittering
	$("#slidez").mousedown(function() {
		return false;
	});
	} );

	////////////////////////
	// Judgment sliders
	////////////////////////
	$( function() {
	var handle = $( "#custom-judgexy" );
	$( "#judgexy" ).slider({
	  orientation: "horizontal",
	  range: "min",
	  min: -1,
	  max: 1,
	  value: 0,
	  create: function() {
	    handle.text('?');
	    // handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
	  },
	  slide: function( event, ui ) {
	  	handle.text(judge_vals[ui.value+1]);
	  }
	});
	//Functionality to stop the controlled sliders jittering
	$("#judgexy").mousedown(function() {
		intervention = 'xy';
		handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
		judged[0] = 1;
		EnablePhase2();
	});
	} );

	$( function() {
	var handle = $( "#custom-judgexz" );
	$( "#judgexz" ).slider({
	  orientation: "horizontal",
	  range: "min",
	  min: -1,
	  max: 1,
	  value: 0,
	  create: function() {
	  	handle.text('?');
	  	//Better to start out 'unset' and force participants to interact with every response
	    // handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
	  },
	  slide: function( event, ui ) {
	  	handle.text(judge_vals[ui.value+1]);
	  }
	});
	//Functionality to stop the controlled sliders jittering
	$("#judgexz").mousedown(function() {
		intervention = 'xz';
		handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
		judged[1] = 1;
		EnablePhase2();
	});
	} );

	$( function() {
	var handle = $( "#custom-judgeyz" );
	$( "#judgeyz" ).slider({
	  orientation: "horizontal",
	  range: "min",
	  min: -1,
	  max: 1,
	  value: 0,
	  create: function() {
	    handle.text('?');
	    // handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
	  },
	  slide: function( event, ui ) {
	  	handle.text(judge_vals[ui.value+1]);
	  }
	});
	//Functionality to stop the controlled sliders jittering
	$("#judgeyz").mousedown(function() {
		intervention = 'yz';
		handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
		judged[2] = 1;
		EnablePhase2();
	});
	} );

	$( function() {
	var handle = $( "#custom-judgezy" );
	$( "#judgezy" ).slider({
	  orientation: "horizontal",
	  range: "min",
	  min: -1,
	  max: 1,
	  value: 0,
	  create: function() {
	    handle.text('?');
	    // handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
	  },
	  slide: function( event, ui ) {
	  	handle.text(judge_vals[ui.value+1]);
	  }
	});
	//Functionality to stop the controlled sliders jittering
	$("#judgezy").mousedown(function() {
		intervention = 'zy';
		handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
		judged[3] = 1;
		EnablePhase2();
	});
	} );

	// setting the top of the reward slider
	$('#greeny').css({top:target_region[rand_target] + '%'})
	$('#greenz').css({top:target_region[rand_target] + '%'})

	// If condition === 0, pick y or z randomly and stay with it for both phases
	if (condition === 0) {
		if (rand_variable === 0) {
			$("#greeny").css({visibility:'visible'})
		} else if (rand_variable === 1) {
			$("#greenz").css({visibility:'visible'})
		} else {
			const err = Error("no target variable selected")
		}
	// if condition === 1, pick y or z randomly to start, and then switch for phase 2
	} else if (condition === 1) {
		if (rand_variable === 0) {
			if (cur_phase === 0) {
				$("#greeny").css({visibility:'visible'})
			} else if (cur_phase === 1) {
				$("#greeny").css({visibility:'hidden'})
				$("#greenz").css({visibility:'visible'})
			}
		} else if (rand_variable === 1) {
			if (cur_phase === 0) {
				$("#greenz").css({visibility:'visible'})
			} else if (cur_phase === 1) {
				$("#greenz").css({visibility:'hidden'})
				$("#greeny").css({visibility:'visible'})
			}
		}
		
	}

	count = 0;
	judged = [0,0,0,0];
	score = 0;
	trial_data = {setup:{"lambda":lambda, "sigma":sigma, "mu":mu},
	x:[], y:[], z:[], interventions:[], score:[], target_max:[], target_min:[]};

	console.log('running with beta1(xy): ', betas[0], ' 2(xz): ', betas[1], ' 3(yx):', betas[2],
	             ' 4(yz): ', betas[3], ' 5(zx):', betas[4], ' 6(zy): ', betas[5], '\n');

	the_process = setInterval(Step, delay, betas, cur_phase);
}



function Step(betas, cur_phase)
{
	count = count+1;

	//Get the control slider colored the right way
	$('#slidex').css({background:'gray'})

	// getting the outputted values of the sliders from the last trial
	var cur_valx = $('#slidex').slider("value")/1000;
	var cur_valy = $('#slidey').slider("value")/1000;
	var cur_valz = $('#slidez').slider("value")/1000;

	// converting reward region into values
	var target_max = 100 - (2*target_region[rand_target]);
	var target_min = target_max - 40; // bad code, as long as height is set to 20% this is fine
		
	if (intervention!=='x')
	{
		//Enabling arrow clicks
		if (int_state==0)
		{ //If no button click, let it move according to the OU process
			var step_x = OU(cur_valx,betas[2]*cur_valy + betas[4]*cur_valz,lambda,sigma)*1000;
		} else if (int_state==1)
		{ //If click 'o', add 10
			var step_x = cur_valx*1000 + 10000;
		} else if (int_state==2)
		{ //If click 'k', hold at current val
			var step_x = cur_valx*1000;
		} else if (int_state==3)
		{ //If click 'm', subtract 10
			var step_x = cur_valx*1000 - 10000;
		}

		// Truncate the values at the limits
		if (step_x>100000)
		{
			step_x  = 100000;
		} else if (step_x< (-100000))
		{
			step_x = -100000;
		}
		$('#slidex').slider("value", step_x);
		$('#custom-handlex').text( Math.round(step_x/1000) );
	}

	if (intervention!=='y')
	{
		var step_y = OU(cur_valy,betas[0]*cur_valx + betas[5]*cur_valz,lambda,sigma)*1000;
		// Truncate the values at the limits
		if (step_y>100000)
		{
			step_y  = 100000;
		} else if (step_y< (-100000))
		{
			step_y = -100000;
		}
		$('#slidey').slider("value", step_y);
		$('#custom-handley').text( Math.round(step_y/1000) );
	}

	if (intervention!=='z')
	{
		var step_z = OU(cur_valz,betas[1]*cur_valx + betas[3]*cur_valy,lambda,sigma)*1000;
		// Truncate the values at the limits
		if (step_z>100000)
		{
			step_z  = 100000
		} else if (step_z< -100000)
		{
			step_z = -100000
		}
		$('#slidez').slider("value", step_z);
		$('#custom-handlez').text( Math.round(step_z/1000) );
	}

	// Calculating scores
	// If condition === 0, pick y or z randomly and stay with it for both phases
	if (condition === 0) {
		if (rand_variable === 0) {
			if (cur_valy <= target_max && cur_valy >= target_min) {score++}
		} else if (rand_variable === 1) {
			if (cur_valz <= target_max && cur_valz >= target_min) {score++}
		} else {
			const err = Error("score cannot be calculated")
		}
	// if condition === 1, pick y or z randomly to start, and then switch for phase 2
	} else if (condition === 1) {
		if (rand_variable === 0) {
			if (cur_phase === 0) {
				if (cur_valy <= target_max && cur_valy >= target_min) {score++}
			} else if (cur_phase === 1) {
				if (cur_valz <= target_max && cur_valz >= target_min) {score++}
			}
		} else if (rand_variable === 1) {
			if (cur_phase === 0) {
				if (cur_valz <= target_max && cur_valz >= target_min) {score++}
			} else if (cur_phase === 1) {
				if (cur_valy <= target_max && cur_valy >= target_min) {score++}
			}
		}
		
	}

	document.getElementById("score_display").innerHTML = "Score: $" + score/100;

	//Save the data from this frame
	trial_data.x.push(cur_valx);
	trial_data.y.push(cur_valy);
	trial_data.z.push(cur_valz);
	trial_data.interventions.push(int_state);
	trial_data.score.push(score);
	trial_data.target_max.push(target_max);
	trial_data.target_min.push(target_min);

	//console.log(trial_data["score"][trial_data["score"].length-1])


	if (stage_off===true)
	{
		stage_off = false;
		intervention = 'none';
	}

	//Print out what's going on
	//if (count % 5 === 0) 
	if (0)
	{
		console.log('step: ', count, 'cur_vals: ', cur_valx, cur_valy, cur_valz,
		            'steps: ', step_x/1000, step_y/1000, step_z/1000,
		            'intervention: ', int_state, 'score: ', score, '\n');
	}

	if ((timeout-count) % 10 === 0)
	{
		document.getElementById("countdown").innerHTML = (timeout-count)/10 + " seconds remaining";
	}

	//Stop at the end
	if (count>timeout)
	{
		console.log(phase)
		Stop();

		//Showing an overlay to start phase 2/3, or next device
		if (cur_phase === 0) 
		{
			showNewPhase();
		} else if (cur_phase === 1) {
			EnableContinue();
		}
	}
}

function OU(x0, cause, lambda, sigma) {
	//NOTE: the "cause" parameter is the value the process trends to. Can be a number 
	//if want to track to that specific number, doesn't have to be another series.
	return (x0 + lambda*(cause-x0) + sigma*myNorm())		
}

function Stop()
{
	console.log('stopping!', trial_data);

	//Resetting the timer
	document.getElementById("countdown").innerHTML = 20 + " seconds remaining";

	//Removing the reward region
	$("#greeny").css({visibility:'hidden'})
	$("#greenz").css({visibility:'hidden'})

	//Resetting the sliders
	$('#slidex').slider("value", 0);
	$('#slidey').slider("value", 0);
	$('#slidez').slider("value", 0);
	$('#custom-handlex').text(0);
	$('#custom-handley').text(0);
	$('#custom-handlez').text(0);

	clearInterval(the_process);
	clearInterval(countdown_timer);
	// SaveData(trial_data); //Now handled in task.js
}

//Generates a standard normal using Box-Mueller transformation
function myNorm() 
{
    var x1, x2, rad;
     do {
        x1 = 2 * Math.random() - 1;
        x2 = 2 * Math.random() - 1;
        rad = x1 * x1 + x2 * x2;
    } while(rad >= 1 || rad == 0);
     var c = Math.sqrt(-2 * Math.log(rad) / rad);
     return (x1 * c);
};

// Interventions end with a mouse up but not necessarily still over the slider
// But the minimum length of an intervention should still be one frame
$(document).mouseup(function() {
		console.log('mouse up on body');
		
		if (intervention!='none')
		{
		    stage_off = true;
		}
	});


//Helper function
function isNotZero(element, index, array) { 
  return element > 0; 
} 

function showNewPhase() {
    // show the mask
    $("#mask").fadeTo(500, 0.25);

    // show the popup
    $("#popup").show();
}

// Allow phase 2 to start
function EnablePhase2()
{
	if (judged.every(isNotZero))
	{
		$('#phase2').attr('disabled', false);
	}
}

//Unlock continue when the user has done what they need to
function EnableContinue()
{
	if (count>timeout)
	{
		$('#next_trial').attr('disabled', false);
	}
}

