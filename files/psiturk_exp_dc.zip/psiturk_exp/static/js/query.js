/////////////////////////////////////////////////
//THIS CONTAINS THE JAVASCRIPT FOR A CAUSAL QUERY
/////////////////////////////////////////////////

var judge_vals = ["inverted","none","regular"];


function query_judge()
{
	$( function() {
	var handle = $( "#custom-judgexy" );
	$( "#judgexy" ).slider({
	  orientation: "horizontal",
	  range: "min",
	  min: -1,
	  max: 1,
	  value: 0,
	  create: function() {
	    handle.text('?');
	    // handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
	  },
	  slide: function( event, ui ) {
	  	handle.text(judge_vals[ui.value+1]);
	  }
	});
	//Functionality to stop the controlled sliders jittering
	$("#judgexy").mousedown(function() {
		intervention = 'xy';
		handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
		judged[0] = 1;
		EnableContinue();
	});
	} );

	$( function() {
		var handle = $( "#custom-judgexz" );
	    $( "#judgexz" ).slider({
	      orientation: "horizontal",
	      range: "min",
	      min: -1,
	      max: 1,
	      value: 0,
	      create: function() {
	      	handle.text('?');
	      	//Better to start out 'unset' and force participants to interact with every response
	        // handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
	      },
	      slide: function( event, ui ) {
	      	handle.text(judge_vals[ui.value+1]);
	      }
	    });
	    //Functionality to stop the controlled sliders jittering
	    $("#judgexz").mousedown(function() {
	    	intervention = 'xz';
	    	handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
	    	judged[1] = 1;
	    	EnableContinue();
		});
	  } );

	$( function() {
		var handle = $( "#custom-judgeyx" );
	    $( "#judgeyx" ).slider({
	      orientation: "horizontal",
	      range: "min",
	      min: -1,
	      max: 1,
	      value: 0,
	      create: function() {
	        handle.text('?');
	        // handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
	      },
	      slide: function( event, ui ) {
	      	handle.text(judge_vals[ui.value+1]);
	      }
	    });
	    //Functionality to stop the controlled sliders jittering
	    $("#judgeyx").mousedown(function() {
	    	intervention = 'yx';
	    	handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
	    	judged[2] = 1;
	    	EnableContinue();
		});
	  } );

	$( function() {
		var handle = $( "#custom-judgeyz" );
	    $( "#judgeyz" ).slider({
	      orientation: "horizontal",
	      range: "min",
	      min: -1,
	      max: 1,
	      value: 0,
	      create: function() {
	        handle.text('?');
	        // handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
	      },
	      slide: function( event, ui ) {
	      	handle.text(judge_vals[ui.value+1]);
	      }
	    });
	    //Functionality to stop the controlled sliders jittering
	    $("#judgeyz").mousedown(function() {
	    	intervention = 'yz';
	    	handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
	    	judged[3] = 1;
	    	EnableContinue();
		});
	  } );

	$( function() {
		var handle = $( "#custom-judgezx" );
	    $( "#judgezx" ).slider({
	      orientation: "horizontal",
	      range: "min",
	      min: -1,
	      max: 1,
	      value: 0,
	      create: function() {
	        handle.text('?');
	        // handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
	      },
	      slide: function( event, ui ) {
	      	handle.text(judge_vals[ui.value+1]);
	      }
	    });
	    //Functionality to stop the controlled sliders jittering
	    $("#judgezx").mousedown(function() {
	    	intervention = 'zx';
	    	handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
	    	judged[4] = 1;
	    	EnableContinue();
		});
	  } );

	$( function() {
		var handle = $( "#custom-judgezy" );
	    $( "#judgezy" ).slider({
	      orientation: "horizontal",
	      range: "min",
	      min: -1,
	      max: 1,
	      value: 0,
	      create: function() {
	        handle.text('?');
	        // handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
	      },
	      slide: function( event, ui ) {
	      	handle.text(judge_vals[ui.value+1]);
	      }
	    });
	    //Functionality to stop the controlled sliders jittering
	    $("#judgezy").mousedown(function() {
	    	intervention = 'zy';
	    	handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
	    	judged[5] = 1;
	    	EnableContinue();
		});
	  } );

	EnableContinue();

	psiTurk.showPage('query.html');



	//Unlock continue when the user has done what they need to
	function EnableContinue()
	{
		$('#next_trial').attr('disabled', false);
	}

}
