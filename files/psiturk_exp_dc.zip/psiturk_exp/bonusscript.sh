#!/usr/bin/env sh
pushd '/Users/neilbramley/Dropbox/active_physics_learning/code/java/Experiments/Experiment_5_mass_or_force/aws-mturk-clt-1.3.1/bin'
./grantBonus.sh -workerid A3696JXTRKL2FI -amount 0.88 -assignment 3PDJHANYK5GF839MIDVI6JTQP89H6E -reason "Bonus for NYU Active Physics Learning task. Thank you"
echo ' --done bonusing participant number A3696JXTRKL2FI' 
./grantBonus.sh -workerid AEXYBW3COL9JM -amount 0.9 -assignment 3SUWZRL0MYD3OTIKSCNCLGWDXSHE6V -reason "Bonus for NYU Active Physics Learning task. Thank you"
echo ' --done bonusing participant number AEXYBW3COL9JM' 
./grantBonus.sh -workerid A36MRQBG3LDR7I -amount 0.83 -assignment 38F5OAUN5NCYC3NR1N0ACXTMKJTH7D -reason "Bonus for NYU Active Physics Learning task. Thank you"
popd