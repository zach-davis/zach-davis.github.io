/*
 * Requires:
 *     psiturk.js
 *     utils.js
 */

// Initalize psiturk object
var psiTurk = new PsiTurk(uniqueId, adServerLoc, mode);

//var mycondition = condition;  // these two variables are passed by the psiturk server process
condition = Math.floor(Math.random() * 4);  //returns a random number from 0 to 3
var mycondition = condition;
var mycounterbalance = counterbalance;  // they tell you which condition you have been assigned to

// All pages to be loaded
var pages = [
	"instructions/instruct-1.html",
	"instructions/instruct-2.html",
	"instructions/instruct-3.html",
	"instructions/instruct-4.html",
	"instructions/instruct-5.html",
	"instructions/instruct-6.html",
	"instructions/instruct-7.html",
	"instructions/instruct-8.html",
	"comprehension-check.html",
	"instructions/instruct-ready.html",
	"interim-instruct.html",
	"stage.html",
	"postquestionnaire.html"
];

psiTurk.preloadPages(pages);

var instructionPages = [ // add as a list as many pages as you like
	"instructions/instruct-1.html",
	"instructions/instruct-2.html",
	"instructions/instruct-3.html",
	"instructions/instruct-4.html",
	"instructions/instruct-5.html",
	"instructions/instruct-6.html",
	"instructions/instruct-7.html",
	"instructions/instruct-8.html"
];

/********************
* The Experiment       *
********************/
var TheExperiment = function() {

	//Keep a note of the current trial
	cur_trial = 0;

	//Shuffle the array of networks to randomise the trial order
	networks = _.shuffle(networks);
	//Illustrating different networks in the instructions
	//networks.unshift({id: ["practice1"], betas:[-1, 0, 0, 0, 1, 0]}) //Just for instructions (chain)
	//networks.unshift({id: ["practice1"], betas:[ 0, 0, 0, 0, 0,-1]}) //Just for instructions (single negative)
	//networks.unshift({id: ["practice1"], betas:[ 1, 0, 0, 0, 0, 0]}) //Just for instructions (single positive)
	//networks.unshift({id: ["practice1"], betas:[ 0, 0, 0, 0, 0, 0]}) // Just for instructions (no connections)

	//Set up the trial structure
	var n_trials = networks.length;
	

	console.log('condition', condition, 'counter', counterbalance);
	//NB: Can change number of conditions and counterbalances in config.txt
	//currently we just have a single condition and counterbalance
	
	next = function() {
		n_trials=networks.length;

		if (cur_trial === networks.length) {
			//Saving condition
			psiTurk.recordTrialData({"real_condition": condition})

			//BONUS
			var get_trial_data = psiTurk.getTrialData();
			//Getting random accuracy 
			var min = 1;
			var max = n_trials;
			var random_trial_phase = Math.floor(Math.random() * (max - min + 1)) + min;
			
			//Assigning bonus
			var exp_bonus = get_trial_data[get_trial_data.length-random_trial_phase]["trialdata"]["accuracy"]
			psiTurk.recordTrialData({"bonus": exp_bonus})
			alert('Congratulations! Your bonus will be $' + exp_bonus*.25 + '. We will contact you shortly to get you your reward.')
			finish();
		} else {
			//Print the current trial info to the console
			console.log('cur_trial:', cur_trial, 'n_trials', n_trials);
			next_trial();
		}

	};

	//Run a trial
	next_trial = function () {
		//Show the trial slide	
		psiTurk.showPage('stage.html');
		
		//Select the current network (this is a list with two elements)
		current_network = networks[cur_trial];

		run_trial = function () {
			Run(current_network.betas);
		}

		$("#stage-start").click(function () {
			run_trial();
			$('#stage-start').prop('disabled', true);
		});

		//Run the OU process code using the current network settings
		//Run(current_network.betas);

		cur_trial = cur_trial + 1;

		//Add various trial specific text below
		//@Zach you might wanna move these around etc.
		////Also they are not actually reactive to the trial so you could just write them in the html
		d3.select("#query1").html('<p id="prompt1">You may move the sliders to help find the connections.</p>');
		d3.select("#query2").html('<p id="prompt2">Select an option for each connection.</p>');
		d3.select("#stage_heading").html('Device ' + cur_trial + ' of ' + n_trials + '.</p>');
	}

	var finish = function() {
	    currentview = new Questionnaire();
	};


	// Load the stage.html snippet into the body of the page
	psiTurk.showPage('stage.html');

	// Start the test
	next();
};

var endTrial = function() {
	//They will probably change their judgment after the 45 seconds is up so this reads the final choice
	var cur_valxy = $('#judgexy').slider("value");
	var cur_valxz = $('#judgexz').slider("value");
	var cur_valyx = $('#judgeyx').slider("value");
	var cur_valyz = $('#judgeyz').slider("value");
	var cur_valzx = $('#judgezx').slider("value");
	var cur_valzy = $('#judgezy').slider("value");
	var final_judgment = {"xy":cur_valxy,"xz":cur_valxz,"yx":cur_valyx,
						  "yz":cur_valyz,"zx":cur_valzx,"zy":cur_valzy};
	var accuracy = (current_network.betas[0] === final_judgment['xy']) +
				   (current_network.betas[1] === final_judgment['xz']) +
				   (current_network.betas[2] === final_judgment['yx']) +
				   (current_network.betas[3] === final_judgment['yz']) +
				   (current_network.betas[4] === final_judgment['zx']) +
				   (current_network.betas[5] === final_judgment['zy'])

	psiTurk.recordTrialData({"phase": "TESTTRIAL",
							"condition": condition,
	                        "trial_ix":current_network.id,
	                        "trial_number":cur_trial,
	                        "network":current_network.betas,
	                        "final_judgment":final_judgment,
	                        "accuracy":accuracy,
	                        "setup":trial_data.setup,
							"x":trial_data.x,
							"y":trial_data.y,
							"z":trial_data.z,
							"ints":trial_data.interventions,
							"xy":trial_data.xy,
							"xz":trial_data.xz,
							"yx":trial_data.yx,
							"yz":trial_data.yz,
							"zx":trial_data.zx,
							"zy":trial_data.zy});
	
	console.log('end trial function fired');

	next();
}

// var nextBlock = function () {
// 	psiTurk.hidePage('interim-instruct.html');
// 	psiTurk.showPage('stage.html');
// }

/*****************
 *  COMPREHENSION CHECK*
 *****************/
var Comprehension = function(){
	psiTurk.showPage('comprehension-check.html')

    //disable button initially
    $('#done_comprehension').prop('disabled', true);

    //checks whether all questions were answered
    comprehension_change_checker = function() {
    	var q1 = $('#comprehension_q1').val();
	    var q2 = $('#comprehension_q2').val();
	    var q3 = $('#comprehension_q3').val();
	    var q4 = $('#comprehension_q4').val();
	    var q5 = $('#comprehension_q5').val();

    	if (q1 === 'noresp' ||
    		q2 === 'noresp' ||
    		q3 === 'noresp' ||
    		q4 === 'noresp' ||
    		q5 === 'noresp')
        {
	        $('#done_comprehension').prop('disabled', true);
	    } else {
	        $('#done_comprehension').prop('disabled', false);
	    }
	};

	//checks whether the answers are correct
	comprehension_checker = function() {
		console.log('comprehension_checker launched')
		   
	       var q1 = $('#comprehension_q1').val();
	       var q2 = $('#comprehension_q2').val();
	       var q3 = $('#comprehension_q3').val();
	       var q4 = $('#comprehension_q4').val();
	       var q5 = $('#comprehension_q5').val();

	       // correct answers 
	        answers = ["true","false","decrease","decrease","true"];

	       if(q1 == answers[0] && q2 == answers[1] && q3 == answers[2] && q4 == answers[3] && q5 == answers[4]){
	            currentview = new TheExperiment();//TestPhase();
	       }else{
	            $('#comprehension_q1').prop('selectedIndex', 0);
	            $('#comprehension_q2').prop('selectedIndex', 0);
	            $('#comprehension_q3').prop('selectedIndex', 0);
	            $('#comprehension_q4').prop('selectedIndex', 0);
	            $('#comprehension_q5').prop('selectedIndex', 0);
	            // currentview = new ComprehensionCheckFail();
	            alert('You answered at least one question incorrectly! Please try again.');
	            currentview = new Instructions();

	       };
	}

	$('.comprehensionQ').change(function() {
		comprehension_change_checker();
	});

	$('#done_comprehension').click(function () { 
		comprehension_checker();
	});
};

/*****************
 *  COMPREHENSION FAIL SCREEN*
 *****************/

var ComprehensionCheckFail = function(){
// Show the slide
$(".slide").hide();
$("#comprehension_check_fail").fadeIn($c.fade);

//unbind previous function calls 
// $('#comprehension').unbind();
// $("#instructions1").find('.next').unbind();
// $("#instructions2-0").find('.next').unbind();
// $("#instructions2-1").find('.next').unbind();
// $("#instructions2-2").find('.next').unbind();

$('#comprehension_fail').click(function () {           
    $('#comprehension_fail').unbind();
    currentview = new Instructions();
   });
}


/****************
* Post test questionnaire *
****************/

var Questionnaire = function() {

	var error_message = "<h1>Oops!</h1><p>Something went wrong submitting your HIT. " + 
	"This might happen if you lose your internet connection. Press the button to resubmit.</p><button id='resubmit'>Resubmit</button>";

	posttest_button_disabler = function () {
		if($("#feedback").val() === '' || $("#age").val() === '' || $("#sex").val() === 'noresp' || $("#engagement").val() === '--' || $("#difficulty").val() === '--') {
			$('#done_posttest').prop('disabled',true);
		} else{
			$('#done_posttest').prop('disabled',false);
		}
	}

	record_responses = function() {
		if($("#feedback").val() === '' || $("#age").val() === '' || $("#sex").val() === 'noresp' || $("#engagement").val() === '--' || $("#difficulty").val() === '--') {
			alert('You must fill all forms');
		} else{
			psiTurk.recordTrialData({'phase':'POSTTEST', 'status':'submit'});

			$('textarea').each( function(i, val) {
				psiTurk.recordUnstructuredData(this.id, this.value);
			});
			$('select').each( function(i, val) {
				psiTurk.recordUnstructuredData(this.id, this.value);		
			});
			$('input').each( function(i, val) {
				psiTurk.recordUnstructuredData(this.id, this.value);		
			});

			//saving the data
			psiTurk.saveData({
			success: function(){
                psiTurk.completeHIT(); // when finished saving compute bonus, the quit
			}, 
			error: prompt_resubmit});
		}
	};

	prompt_resubmit = function() {
		document.body.innerHTML = error_message;
		$("#resubmit").click(resubmit);
	};

	resubmit = function() {
		document.body.innerHTML = "<h1>Trying to resubmit...</h1>";
		reprompt = setTimeout(prompt_resubmit, 10000);
		
		psiTurk.saveData({
			success: function() {
				clearInterval(reprompt); 
				psiTurk.computeBonus('compute_bonus', function(){finish()}); 
			}, 
			error: prompt_resubmit
		});
	};

	// Load the questionnaire snippet 
	psiTurk.showPage('postquestionnaire.html');
	psiTurk.recordTrialData({'phase':'POSTTEST', 'status':'begin'});
	
	$(".posttestQ").change(function () {
		posttest_button_disabler();
	})

	$("#done_posttest").click(function () {
		record_responses();
	});

	
};

// Task object to keep track of the current phase
var currentview;

/*******************
 * Run Task
 ******************/
 $(window).load( function(){
 	psiTurk.doInstructions(
    	instructionPages, // a list of pages you want to display in sequence
    	function() {
	    	// Load the data from the json then start the exp
	    	$.getJSON('/static/json/stim.json', function (data) {
	    		console.log(data);
	    		networks = data.networks;
	      		// Load the experiment configuration from the server
	      		currentview = new Comprehension();//TheExperiment();
	      	});
     } // what you want to do when you are done with instructions
     );
 });
