//////////////////////////////////////////
//THIS CONTAINS THE JAVASCRIPT FOR A TRIAL
//////////////////////////////////////////


var count = 0; //For keeping track of how long the process has run for
//var timeout = 450;//450;//How many steps to run for (10 steps per second)
var mu = 0;
var sigma = 5;
var x0 = 0;
var intervention = 'none';
var stage_off = false;
var trial_data = {};
var judge_vals = ["inverted","none","regular"];
var judged = [0,0,0,0,0,0];//Which response sliders has the participant clicked on?
var the_process;

// changing by condition the refresh rate and tightness of the process
var mycondition = condition;
if (mycondition === 0) {
  var delay   = 100; //How many ms per step
  var timeout = 450;
  var omega   = .1;
} else if (mycondition === 1) {
  var delay   = 100;
  var timeout = 450;
  var omega   = .05;
} else if (mycondition === 2) {
  var delay   = 300;
  var timeout = 150;
  var omega   = .1;
} else if (mycondition === 3) {
  var delay   = 300;
  var timeout = 150;
  var omega   = .05;
}


// var networks = [
//  [xy,xz,yx,yz,zx,zy]
// 	[ 1, 0, 0, 0, 1, 0], //       single cause (+): x>y
// 	[ 0, 0, 0,-1, 0, 0], //       single cause (-): z>y
// 	[ 0, 0, 0, 1, 1, 0], //            chain (+,+): y>z, z>x
// 	[ 0,-1, 1, 0, 0, 0], //            chain (+,-): y>x, x>z
// 	[-1, 0, 0,-1, 0, 0], //            chain (-,-): x>y, y>z
// 	[ 0, 0, 1, 0, 1, 1], //simpson paradox (+,+,+): z>x, z>y, y>x
// 	[ 0, 1, 1,-1, 0, 0], //simpson paradox (+,+,-): y>x, x>z, y>z
//  [-1, 0, 0, 0,-1,-1], //simpson paradox (-,-,-): x>y, z>y, z>x
// 	[ 1, 1, 0, 0, 0, 0], //     common cause (+,+): x>y, x>z
// 	[ 0, 0,-1, 1, 0, 0], //     common cause (+,-): y>x, y>z
// 	[ 0, 0, 0, 0,-1,-1], //     common cause (-,-): z>x, z>y
// 	[ 0, 0, 1, 0, 1, 0], //    common effect (+,+): y>x, z>x
// 	[-1, 0, 0, 0, 0, 1], //    common effect (+,-): x>y, z>y
//  [ 0,-1, 0,-1, 0, 0], //    common effect (-,-): x>z, y>z
// 	[ 0, 0, 0, 1, 0, 1], //    feedback loop (+,+): y>z, z>y
// 	[ 0, 1, 0, 0,-1, 0], //    feedback loop (+,-): x>z, z>x
// 	[-1, 0,-1, 0, 0, 0], //    feedback loop (-,-): x>y, y>x
// 	[ 0, 0,-1,-1, 0,-1], // FL w/ offshoot (-,-;-): y>z, z>y, y>x
// 	[ 1,-1, 1, 0, 0, 0], // FL w/ offshoot (+,+;-): x>y, y>x, x>z
// 	[ 0, 1, 0, 0,-1, 1], // FL w/ offshoot (+,-;+): x>z, z>x, z>y
// 	[ 0, 1, 0, 1, 0, 1], //  FL w/ feed-in (+,+;+): y>z, z>y, x>z
// 	[-1, 0, 1, 0, 0, 1], //  FL w/ feed-in (-,+;+): x>y, y>x, z>y
// 	[ 0, 1,-1, 0, 1, 0], //  FL w/ feed-in (+,+;-): x>z, z>x, y>x
// 	[ 1,-1, 1, 0, 0, 1], //  FL w/ chain (+,+;-,+): x>y, y>x, x>z, z>y <=== really hard
// 	[ 1,-1, 0, 1,-1, 0]  //  FL w/ chain (-,-;+,+): x>z, z>x, x>y, y>z <=== really hard
//  [ 1, 0, 0, 0, 0, 0]  // Instructions (single pos)
//  [ 0, 0, 0, 0, 0,-1]  // Instructions (single neg)
//  [-1, 0, 0, 0, 1, 0]  // instructions (chain)
//  [ 6, 6, 7, 5, 4, 7]  // counts of positive relationships
//  [ 5, 4, 4, 4, 4, 4]  // counts of negative relationships
// ];

var TimeCounter = function () {
  current_time--
  document.getElementById("countdown").innerHTML = current_time + " seconds remaining";
}

// Update the count down every 1 second
var countdown_timer = setInterval(function() {

    // Get todays date and time
    var now = Date.parse(new Date());
    // Get time of deadline
    var trial_duration = timeout/10;//Timeout in seconds
    var deadline = new Date(now + trial_duration*60*1000);
    
    // Find the distance between now an the count down date
    var distance = deadline - now;
    
    // Time calculations for days, hours, minutes and seconds
    // var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    // var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    // var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
    // Output the result in an element with id="demo"
    // d3.select("#countdown").html(days + "d " + hours + "h "
    // + minutes + "m " + seconds + "s ");

    // document.getElementById("countdown").innerHTML = days + "d " + hours + "h "
    // + minutes + "m " + seconds + "s ";
    
    // If the count down is over, write some text 
    // if (distance < 0) {
    //     clearInterval(x);
    //     document.getElementById("countdown").innerHTML = "EXPIRED";
    // }
}, 1000);


//For updating the text box next to each slider to the sliders' value
function updateOutput(el, val) {
  el.textContent = val;
}

function Run(betas)
{
	$( function() {
	var handle = $( "#custom-handlex" );
    $( "#slidex" ).slider({
      orientation: "vertical",
      animate: true,
      range: "min",
      min: -100000,
      max: 100000,
      value: 0,
      create: function() {
        handle.text( Math.round($( this ).slider( "value" )/1000) );
      },
      slide: function( event, ui ) {
      	handle.text(Math.round(ui.value/1000));
      }
    });
    //Functionality to stop the controlled sliders jittering
    $("#slidex").mousedown(function() {
    	intervention = 'x';
	});
  } );

$( function() {
	var handle = $( "#custom-handley" );
    $( "#slidey" ).slider({
      orientation: "vertical",
      animate: true,
      range: "min",
      min: -100000,
      max: 100000,
      value: 0,
      create: function() {
        handle.text( $( this ).slider( "value" ) );
      },
      slide: function( event, ui ) {
      	handle.text(Math.round(ui.value/1000));
      }
    });
    //Functionality to stop the controlled sliders jittering
    $("#slidey").mousedown(function() {
    	intervention = 'y';
	});
  } );

$( function() {
	var handle = $( "#custom-handlez" );
    $( "#slidez" ).slider({
      orientation: "vertical",
      animate: true,
      range: "min",
      min: -100000,
      max: 100000,
      value: 0,
      create: function() {
        handle.text( $( this ).slider( "value" ) );
      },
      slide: function( event, ui ) {
      	handle.text(Math.round(ui.value/1000));
      }
    });
    //Functionality to stop the controlled sliders jittering
    $("#slidez").mousedown(function() {
    	intervention = 'z';
	});
  } );


////////////////////////
// Judgment sliders
////////////////////////
$( function() {
	var handle = $( "#custom-judgexy" );
    $( "#judgexy" ).slider({
      orientation: "horizontal",
      range: "min",
      min: -1,
      max: 1,
      value: 0,
      create: function() {
        handle.text('?');
        // handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
      },
      slide: function( event, ui ) {
      	handle.text(judge_vals[ui.value+1]);
      }
    });
    //Functionality to stop the controlled sliders jittering
    $("#judgexy").mousedown(function() {
    	intervention = 'xy';
    	handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
    	judged[0] = 1;
    	EnableContinue();
	});
  } );

$( function() {
	var handle = $( "#custom-judgexz" );
    $( "#judgexz" ).slider({
      orientation: "horizontal",
      range: "min",
      min: -1,
      max: 1,
      value: 0,
      create: function() {
      	handle.text('?');
      	//Better to start out 'unset' and force participants to interact with every response
        // handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
      },
      slide: function( event, ui ) {
      	handle.text(judge_vals[ui.value+1]);
      }
    });
    //Functionality to stop the controlled sliders jittering
    $("#judgexz").mousedown(function() {
    	intervention = 'xz';
    	handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
    	judged[1] = 1;
    	EnableContinue();
	});
  } );

$( function() {
	var handle = $( "#custom-judgeyx" );
    $( "#judgeyx" ).slider({
      orientation: "horizontal",
      range: "min",
      min: -1,
      max: 1,
      value: 0,
      create: function() {
        handle.text('?');
        // handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
      },
      slide: function( event, ui ) {
      	handle.text(judge_vals[ui.value+1]);
      }
    });
    //Functionality to stop the controlled sliders jittering
    $("#judgeyx").mousedown(function() {
    	intervention = 'yx';
    	handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
    	judged[2] = 1;
    	EnableContinue();
	});
  } );

$( function() {
	var handle = $( "#custom-judgeyz" );
    $( "#judgeyz" ).slider({
      orientation: "horizontal",
      range: "min",
      min: -1,
      max: 1,
      value: 0,
      create: function() {
        handle.text('?');
        // handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
      },
      slide: function( event, ui ) {
      	handle.text(judge_vals[ui.value+1]);
      }
    });
    //Functionality to stop the controlled sliders jittering
    $("#judgeyz").mousedown(function() {
    	intervention = 'yz';
    	handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
    	judged[3] = 1;
    	EnableContinue();
	});
  } );

$( function() {
	var handle = $( "#custom-judgezx" );
    $( "#judgezx" ).slider({
      orientation: "horizontal",
      range: "min",
      min: -1,
      max: 1,
      value: 0,
      create: function() {
        handle.text('?');
        // handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
      },
      slide: function( event, ui ) {
      	handle.text(judge_vals[ui.value+1]);
      }
    });
    //Functionality to stop the controlled sliders jittering
    $("#judgezx").mousedown(function() {
    	intervention = 'zx';
    	handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
    	judged[4] = 1;
    	EnableContinue();
	});
  } );

$( function() {
	var handle = $( "#custom-judgezy" );
    $( "#judgezy" ).slider({
      orientation: "horizontal",
      range: "min",
      min: -1,
      max: 1,
      value: 0,
      create: function() {
        handle.text('?');
        // handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
      },
      slide: function( event, ui ) {
      	handle.text(judge_vals[ui.value+1]);
      }
    });
    //Functionality to stop the controlled sliders jittering
    $("#judgezy").mousedown(function() {
    	intervention = 'zy';
    	handle.text( judge_vals[ $( this ).slider( "value" )+1 ] );
    	judged[5] = 1;
    	EnableContinue();
	});
  } );

	count = 0;
	judged = [0,0,0,0,0,0];
  current_time = 45;
	trial_data = {setup:{"omega":omega, "sigma":sigma, "mu":mu},
	x:[], y:[],z:[],xy:[],xz:[],yx:[],yz:[],zx:[],zy:[], interventions:[]};

	console.log('running with beta1: ', betas[0], ' 2: ', betas[1], ' 3:', betas[2],
	             ' 4: ', betas[3], ' 5:', betas[4], ' 6: ', betas[5], '\n');

	the_process = setInterval(Step, delay, betas);
  countdown_timer = setInterval(TimeCounter, 1000);
}


function Step(betas)
{
	count = count+1;

	var cur_valx = $('#slidex').slider("value")/1000;
  	var cur_valy = $('#slidey').slider("value")/1000;
	var cur_valz = $('#slidez').slider("value")/1000;

	var cur_valxy = $('#judgexy').slider("value");
	var cur_valxz = $('#judgexz').slider("value");
	var cur_valyx = $('#judgeyx').slider("value");
	var cur_valyz = $('#judgeyz').slider("value");
	var cur_valzx = $('#judgezx').slider("value");
	var cur_valzy = $('#judgezy').slider("value");

		
	if (intervention!=='x')
	{
		var step_x = OU(cur_valx,betas[2]*cur_valy + betas[4]*cur_valz,omega,sigma, beta=1)*1000;
		// Truncate the values at the limits
		if (step_x>100000)
		{
			step_x  = 100000;
		} else if (step_x< (-100000))
		{
			step_x = -100000;
		}
		$('#slidex').slider("value", step_x);
		$('#custom-handlex').text( Math.round(step_x/1000) );
	}

	if (intervention!=='y')
	{
		var step_y = OU(cur_valy,betas[0]*cur_valx + betas[5]*cur_valz,omega,sigma, beta=1)*1000;
		// Truncate the values at the limits
		if (step_y>100000)
		{
			step_y  = 100000;
		} else if (step_y< (-100000))
		{
			step_y = -100000;
		}
		$('#slidey').slider("value", step_y);
		$('#custom-handley').text( Math.round(step_y/1000) );
	}

	if (intervention!=='z')
	{
		var step_z = OU(cur_valz,betas[1]*cur_valx + betas[3]*cur_valy,omega,sigma, beta=1)*1000;
				// Truncate the values at the limits
		if (step_z>100000)
		{
			step_z  = 100000
		} else if (step_z< -100000)
		{
			step_z = -100000
		}
		$('#slidez').slider("value", step_z);
		$('#custom-handlez').text( Math.round(step_z/1000) );
		EnableContinue();
	}
	
	//Save the data from this frame
	trial_data.x.push(cur_valx);
	trial_data.y.push(cur_valy);
	trial_data.z.push(cur_valz);
	trial_data.xy.push(cur_valxy);
	trial_data.xz.push(cur_valxz);
	trial_data.yx.push(cur_valyx);
	trial_data.yz.push(cur_valyz);
	trial_data.zx.push(cur_valzx);
	trial_data.zy.push(cur_valzy);
	
	trial_data.interventions.push(intervention);

	if (stage_off===true)
	{
		stage_off = false;
		intervention = 'none';
	}

	//Print out what's going on
	//if (count % 5 === 0) 
  if (0)
	{
		console.log('step: ', count, 'cur_vals: ', cur_valx, cur_valy, cur_valz,
		            'steps: ', step_x/1000, step_y/1000, step_z/1000,
		            'intervention: ', intervention, '\n');
	}

	//if ((timeout-count) % 10 === 0)
	//{
	//	document.getElementById("countdown").innerHTML = (timeout-count)/10 + " seconds remaining";
	//}

	//Stop at the end
	if (count>timeout)
	{
		Stop();
	}
}

function OU(x0, cause, omega, sigma, beta) {
	//NOTE: the "cause" parameter can be a number if want to track 
	//to that specific number, doesn't have to be another series.
	//NOTE BETA MUST BE 1 AS COMBINATION OF BETAS AND INPUTS IS COMPUTED BEFORE BEGIN GIVEN TO THIS FUNCTION
	return (x0 + omega*(beta*cause-x0) + sigma*myNorm())		
}

function Stop()
{
	EnableContinue();
	
	console.log('stopping!', trial_data);

	clearInterval(the_process);
	clearInterval(countdown_timer);
	// SaveData(trial_data); //Now handled in task.js
}

//Generates a standard normal using Box-Mueller transformation
function myNorm() 
{
    var x1, x2, rad;
     do {
        x1 = 2 * Math.random() - 1;
        x2 = 2 * Math.random() - 1;
        rad = x1 * x1 + x2 * x2;
    } while(rad >= 1 || rad == 0);
     var c = Math.sqrt(-2 * Math.log(rad) / rad);
     return (x1 * c);
};

// Interventions end with a mouse up but not necessarily still over the slider
// But the minimum length of an intervention should still be one frame
$(document).mouseup(function() {
		console.log('mouse up on body');
		
		if (intervention!='none')
		{
		    stage_off = true;
		}
	});


//Helper function
function isNotZero(element, index, array) { 
  return element > 0; 
} 

//$(document).checked(function() {
  //  if ($('input[name=gender]:checked').length > 0) {
      // do something here
 //   }

//}

//Unlock continue when the user has done what they need to
function EnableContinue()
{
	if (count>timeout & judged.every(isNotZero))
	{
		$('#next_trial').attr('disabled', false);
	}
}

